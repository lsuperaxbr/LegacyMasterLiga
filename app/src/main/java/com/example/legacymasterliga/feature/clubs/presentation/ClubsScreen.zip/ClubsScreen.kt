package com.example.legacymasterliga.feature.clubs.presentation

import android.content.Intent
import android.net.Uri
import android.widget.ImageView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.ToggleOff
import androidx.compose.material.icons.outlined.ToggleOn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.legacymasterliga.domain.model.Club
import com.example.legacymasterliga.domain.model.League
import com.example.legacymasterliga.domain.model.User
import com.example.legacymasterliga.core.model.UserRole
import com.example.legacymasterliga.core.model.AccountStatus
import com.example.legacymasterliga.core.ui.components.ClubCrest

@Composable
fun ClubsRoute(
    onBack: () -> Unit,
    onOpenProfile: (Long) -> Unit,
    readOnly: Boolean = false,
    viewModel: ClubsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    ClubsScreen(
        state = state,
        onBack = onBack,
        onOpenProfile = onOpenProfile,
        readOnly = readOnly,
        onSelectLeague = viewModel::selectLeague,
        onSaveClub = viewModel::saveClub,
        onDeleteClub = viewModel::deleteClub,
        onSetClubActive = viewModel::setClubActive,
        onFeedbackConsumed = viewModel::clearFeedback,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClubsScreen(
    state: ClubsUiState,
    onBack: () -> Unit,
    onOpenProfile: (Long) -> Unit,
    readOnly: Boolean,
    onSelectLeague: (Long) -> Unit,
    onSaveClub: (Long?, String, String?, Long?, Long) -> Unit,
    onDeleteClub: (Long) -> Unit,
    onSetClubActive: (Long, Boolean) -> Unit,
    onFeedbackConsumed: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var editingClub by remember { mutableStateOf<Club?>(null) }
    var clubToDelete by remember { mutableStateOf<Club?>(null) }
    var showClubDialog by rememberSaveable { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.feedback) {
        val item = state.feedback ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(
            when (item) {
                is ClubFeedback.Success -> item.message
                is ClubFeedback.Error -> item.message
            },
        )
        onFeedbackConsumed()
        if (item is ClubFeedback.Success) {
            showClubDialog = false
            editingClub = null
            clubToDelete = null
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Clubes") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "Voltar")
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            if (!readOnly) {
                FloatingActionButton(
                    onClick = {
                        editingClub = null
                        showClubDialog = true
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                ) {
                    Icon(Icons.Outlined.Add, contentDescription = "Criar clube")
                }
            }
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                top = innerPadding.calculateTopPadding() + 16.dp,
                end = 16.dp,
                bottom = innerPadding.calculateBottomPadding() + 96.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text("Liga selecionada", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                LeagueSelector(
                    leagues = state.leagues,
                    selectedLeagueId = state.selectedLeagueId,
                    onSelect = onSelectLeague,
                )
            }

            if (state.selectedLeagueId == null) {
                item { EmptyState("Crie uma liga no módulo Competições antes de cadastrar clubes.") }
            } else if (state.clubs.isEmpty()) {
                item { EmptyState("Nenhum clube cadastrado nesta liga. Use o botão + para criar o primeiro.") }
            } else {
                items(state.clubs, key = { "cl_${it.id}" }) { club ->
                    ClubCard(
                        club = club,
                        presidentName = state.users.firstOrNull { it.id == club.presidentUserId }?.displayName,
                        onEdit = if (readOnly) null else ({
                            editingClub = club
                            showClubDialog = true
                        }),
                        onDelete = if (readOnly) null else ({ clubToDelete = club }),
                        onToggleActive = if (readOnly) null else ({ onSetClubActive(club.id, !club.isActive) }),
                        onOpenProfile = { onOpenProfile(club.id) },
                    )
                }
            }
        }
    }

    if (showClubDialog && !readOnly) {
        ClubEditorDialog(
            club = editingClub,
            users = state.users.filter { it.status == AccountStatus.ACTIVE },
            onDismiss = {
                showClubDialog = false
                editingClub = null
            },
            onConfirm = { name, crestUri, presidentUserId, initialBalance ->
                onSaveClub(editingClub?.id, name, crestUri, presidentUserId, initialBalance)
            },
        )
    }

    if (clubToDelete != null) {
        AlertDialog(
            onDismissRequest = { clubToDelete = null },
            title = { Text("Excluir clube") },
            text = { Text("Deseja excluir o clube ${clubToDelete?.name}? Esta ação não pode ser desfeita e falhará se houver histórico vinculado.") },
            confirmButton = {
                TextButton(onClick = { onDeleteClub(clubToDelete!!.id) }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) {
                    Text("Excluir")
                }
            },
            dismissButton = { TextButton(onClick = { clubToDelete = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun LeagueSelector(
    leagues: List<League>,
    selectedLeagueId: Long?,
    onSelect: (Long) -> Unit,
) {
    if (leagues.isEmpty()) {
        Text("Nenhuma liga disponível.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        leagues.forEach { league ->
            AssistChip(
                onClick = { onSelect(league.id) },
                label = { Text("${league.name} • ${league.currencyCode}") },
                leadingIcon = if (selectedLeagueId == league.id) {
                    { Icon(Icons.Outlined.Groups, contentDescription = null) }
                } else null,
            )
        }
    }
}

@Composable
private fun ClubCard(
    club: Club,
    presidentName: String?,
    onEdit: (() -> Unit)?,
    onDelete: (() -> Unit)?,
    onToggleActive: (() -> Unit)?,
    onOpenProfile: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().alpha(if (club.isActive) 1f else 0.62f),
        colors = CardDefaults.cardColors(
            containerColor = if (club.isActive) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant,
        ),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ClubCrest(club.name, club.crestUri, modifier = Modifier.size(76.dp))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(club.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    presidentName?.let { "Presidente: $it" } ?: "Sem presidente associado",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(if (club.isActive) "Ativo" else "Desativado", style = MaterialTheme.typography.labelLarge)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(onClick = onOpenProfile) {
                    Icon(Icons.Outlined.Info, contentDescription = "Ver perfil de ${club.name}")
                }
                if (onEdit != null) {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Outlined.Edit, contentDescription = "Editar ${club.name}")
                    }
                }
                if (onDelete != null) {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Outlined.Delete, contentDescription = "Excluir ${club.name}", tint = MaterialTheme.colorScheme.error)
                    }
                }
                if (onToggleActive != null) {
                    IconButton(onClick = onToggleActive) {
                        Icon(
                            if (club.isActive) Icons.Outlined.ToggleOn else Icons.Outlined.ToggleOff,
                            contentDescription = if (club.isActive) "Desativar ${club.name}" else "Ativar ${club.name}",
                            tint = if (club.isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ClubEditorDialog(
    club: Club?,
    users: List<User>,
    onDismiss: () -> Unit,
    onConfirm: (String, String?, Long?, Long) -> Unit,
) {
    val context = LocalContext.current
    var name by rememberSaveable(club?.id) { mutableStateOf(club?.name.orEmpty()) }
    var crestUri by rememberSaveable(club?.id) { mutableStateOf(club?.crestUri) }
    var selectedPresidentId by rememberSaveable(club?.id) { mutableStateOf(club?.presidentUserId) }
    var initialBalance by rememberSaveable(club?.id) { mutableStateOf("") }
    var presidentMenuExpanded by remember { mutableStateOf(false) }

    val crestPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            crestUri = uri.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (club == null) "Novo clube" else "Editar clube") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ClubCrest(name.ifBlank { "CL" }, crestUri, modifier = Modifier.size(72.dp))
                    OutlinedButton(onClick = { crestPicker.launch(arrayOf("image/*")) }) {
                        Icon(Icons.Outlined.Image, contentDescription = null)
                        Spacer(Modifier.size(8.dp))
                        Text("Escolher escudo")
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome do clube") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )

                if (club == null) {
                    OutlinedTextField(
                        value = initialBalance,
                        onValueChange = { initialBalance = it.filter { c -> c.isDigit() } },
                        label = { Text("Saldo Inicial (CR)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                ExposedDropdownMenuBox(
                    expanded = presidentMenuExpanded,
                    onExpandedChange = { presidentMenuExpanded = !presidentMenuExpanded },
                ) {
                    val selectedName = users.firstOrNull { it.id == selectedPresidentId }?.displayName ?: "Sem presidente"
                    OutlinedTextField(
                        value = selectedName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Presidente") },
                        leadingIcon = { Icon(Icons.Outlined.Badge, contentDescription = null) },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = presidentMenuExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                    )
                    ExposedDropdownMenu(
                        expanded = presidentMenuExpanded,
                        onDismissRequest = { presidentMenuExpanded = false },
                    ) {
                        DropdownMenuItem(
                            text = { Text("Sem presidente") },
                            onClick = {
                                selectedPresidentId = null
                                presidentMenuExpanded = false
                            },
                        )
                        users.forEach { user ->
                            DropdownMenuItem(
                                text = { Text("${user.displayName} (@${user.username})") },
                                onClick = {
                                    selectedPresidentId = user.id
                                    presidentMenuExpanded = false
                                },
                            )
                        }
                    }
                }

                if (!crestUri.isNullOrBlank()) {
                    OutlinedButton(onClick = { crestUri = null }) { Text("Remover escudo") }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(name, crestUri, selectedPresidentId, initialBalance.toLongOrNull() ?: 0L) }, enabled = name.trim().length >= 2) {
                Text("Salvar")
            }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
private fun EmptyState(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Outlined.Groups, contentDescription = null, modifier = Modifier.size(42.dp))
            Text(message, style = MaterialTheme.typography.bodyLarge)
        }
    }
}
