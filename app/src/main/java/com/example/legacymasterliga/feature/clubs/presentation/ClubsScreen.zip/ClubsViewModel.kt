package com.example.legacymasterliga.feature.clubs.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.legacymasterliga.domain.model.Club
import com.example.legacymasterliga.domain.model.League
import com.example.legacymasterliga.domain.model.User
import com.example.legacymasterliga.domain.repository.ClubRepository
import com.example.legacymasterliga.domain.repository.LeagueRepository
import com.example.legacymasterliga.domain.repository.UserRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class ClubsViewModel @Inject constructor(
    private val clubRepository: ClubRepository,
    leagueRepository: LeagueRepository,
    userRepository: UserRepository,
) : ViewModel() {
    private val selectedLeagueId = MutableStateFlow<Long?>(null)
    private val feedback = MutableStateFlow<ClubFeedback?>(null)

    private val leagues = leagueRepository.observeAll()
    private val users = userRepository.observeAll()
    private val clubs = selectedLeagueId.flatMapLatest { leagueId ->
        if (leagueId == null) flowOf(emptyList()) else clubRepository.observeManagedByLeague(leagueId)
    }

    val uiState: StateFlow<ClubsUiState> = combine(
        leagues,
        users,
        selectedLeagueId,
        clubs,
        feedback,
    ) { leagueList, userList, selectedId, clubList, currentFeedback ->
        val effectiveId = selectedId ?: leagueList.firstOrNull()?.id
        if (selectedId == null && effectiveId != null) selectedLeagueId.value = effectiveId
        ClubsUiState(
            leagues = leagueList,
            users = userList,
            selectedLeagueId = effectiveId,
            clubs = clubList,
            feedback = currentFeedback,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ClubsUiState())

    fun selectLeague(leagueId: Long) {
        selectedLeagueId.value = leagueId
        feedback.value = null
    }

    fun saveClub(
        clubId: Long?,
        name: String,
        crestUri: String?,
        presidentUserId: Long?,
        initialBalance: Long = 0L,
    ) {
        val leagueId = selectedLeagueId.value
        if (leagueId == null) {
            feedback.value = ClubFeedback.Error("Selecione uma liga primeiro.")
            return
        }
        val normalizedName = name.trim()
        if (normalizedName.length < 2) {
            feedback.value = ClubFeedback.Error("Informe um nome de clube válido.")
            return
        }
        viewModelScope.launch {
            runCatching {
                if (clubId == null) {
                    clubRepository.create(leagueId, normalizedName, crestUri, presidentUserId, initialBalance)
                } else {
                    clubRepository.update(clubId, leagueId, normalizedName, crestUri, presidentUserId)
                }
            }.onSuccess {
                feedback.value = ClubFeedback.Success(if (clubId == null) "Clube criado com sucesso." else "Clube atualizado com sucesso.")
            }.onFailure { error ->
                val message = if (error.message?.contains("UNIQUE", ignoreCase = true) == true) {
                    "Já existe um clube com esse nome nesta liga."
                } else {
                    error.message ?: "Não foi possível salvar o clube."
                }
                feedback.value = ClubFeedback.Error(message)
            }
        }
    }

    fun deleteClub(clubId: Long) {
        viewModelScope.launch {
            runCatching { clubRepository.delete(clubId) }
                .onSuccess { feedback.value = ClubFeedback.Success("Clube excluído com sucesso.") }
                .onFailure { error -> feedback.value = ClubFeedback.Error(error.message ?: "Não foi possível excluir o clube.") }
        }
    }

    fun setClubActive(clubId: Long, active: Boolean) {
        viewModelScope.launch {
            runCatching { clubRepository.setActive(clubId, active) }
                .onSuccess { feedback.value = ClubFeedback.Success(if (active) "Clube ativado." else "Clube desativado.") }
                .onFailure { error -> feedback.value = ClubFeedback.Error(error.message ?: "Não foi possível atualizar o clube.") }
        }
    }

    fun clearFeedback() {
        feedback.value = null
    }
}

data class ClubsUiState(
    val leagues: List<League> = emptyList(),
    val users: List<User> = emptyList(),
    val selectedLeagueId: Long? = null,
    val clubs: List<Club> = emptyList(),
    val feedback: ClubFeedback? = null,
)

sealed interface ClubFeedback {
    data class Success(val message: String) : ClubFeedback
    data class Error(val message: String) : ClubFeedback
}
